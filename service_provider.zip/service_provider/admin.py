from django.contrib import admin
from .models import Service_Type, Collar
# Register your models here.

admin.site.register(Service_Type)
admin.site.register(Collar)